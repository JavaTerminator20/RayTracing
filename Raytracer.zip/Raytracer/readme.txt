Main file is "Raytracer.jl".
To create a scene run a scene file in "scenes" folder. Images will be saved in "images" folder.
All scenes are already rendered in 4k in "prerendered iamges" folder.