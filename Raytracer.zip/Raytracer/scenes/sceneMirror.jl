include("../Raytracer.jl")

# Name of the image file
name = "images/Mirror.png"

# Camera or Rays
CameraDirection = [1;0;0]
CameraRotation = [0.0;0.0;0.0]
CameraPosition = [0.0;0.0;0.0]
CameraFOV = 90
CameraAspectRatio = [16;10]
CameraResolution = [3840;2400]

# Lights
Lights_host = [
    Light(Global, 0.0f0, (5.0f0, -10.0f0, -20.0f0), (1.0f0, 1.0f0, 1.0f0))
]

# Objects
Objects_host = [
    Object(Sphere, (10.0f0,0.0f0, 2.0f0), (4.0f0, 0.0f0, 0.0f0), (0.5f0, 0.5f0, 0.5f0), 2),
    Object(Sphere, (5.0f0,-3.5f0, 2.0f0), (1.0f0, 0.0f0, 0.0f0), (1.0f0, 0.0f0, 0.0f0), 1),
    Object(Sphere, (3.0f0,-2.0f0, -1.0f0), (0.65f0, 0.0f0, 0.0f0), (0.0f0, 1.0f0, 0.0f0), 1),
    Object(Sphere, (5.0f0, 1.5f0, -1.0f0), (1.0f0, 3.0f0, 0.0f0), (1.0f0, 0.0f0, 1.0f0), 1),
    Object(Plane, (0.0f0, 0.0f0, 1.0f0), (3.0f0, 0.0f0, 0.0f0), (1.0f0, 1.0f0, 1.0f0), 1)
]

# background color
const bg_color::SVector{3, Float32} = SVector{3, Float32}(0.4, 0.45,0.5)

# how much of the color mirrors reflects
const c_reflectivity = 0.8f0
# maximum number of mirror to mirror bounces
const c_bounces = 15

# bigger number means less specular light
const c_specularArea = 20.f0

# Run the raytracer
raytracer(CameraResolution, CameraAspectRatio, CameraFOV, CameraRotation, CameraDirection, CameraPosition, Objects_host, Lights_host, name)


#struct Object
#    type::ObjectType #Sphere, Plane, Torus, Elips, F1 (wavy)
#
#    xyz::SVector{3, Float32}
#    abc::SVector{3, Float32}
#
#    color::SVector{3, Float32}
#    material::Int32 # 1-normal, 2-mirror, 3-glass, 4-normal,no specular
#end

#struct Light
#    type::LightType #Global, Point
#
#    power::Float32
#    source::SVector{3, Float32} #represents direction when Global, position when Point
#    color::SVector{3, Float32}
#end